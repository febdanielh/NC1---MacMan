//
//  ContentView.swift
//  test pacman
//
//  Created by Febrian Daniel on 20/03/23.
//

import SwiftUI

enum DisplayScreen{
    case loadingScreen
    case maze
}

struct ContentView: View {
    @State var currentDisplayScreen: DisplayScreen = .loadingScreen
    
    var body: some View {
//        Loading_Screen()
        switch currentDisplayScreen {
        case .loadingScreen:
            Loading_Screen(currentDisplayScreen: $currentDisplayScreen)
        case .maze:
            Maze()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
