//
//  Truth Or Dare.swift
//  test pacman
//
//  Created by Febrian Daniel on 23/03/23.
//

import SwiftUI

struct Truth_Or_Dare: View {
    var body: some View {
        ZStack {
            Color.black
            VStack {
                Text("CHOOSE!")
                    .font(.custom("Retro Gaming", size: 70))
                    .foregroundColor(.orange)
                    
                Spacer()
                    .frame(height: 100)
            }
        }
    }
}

struct Truth_Or_Dare_Previews: PreviewProvider {
    static var previews: some View {
        Truth_Or_Dare()
    }
}
