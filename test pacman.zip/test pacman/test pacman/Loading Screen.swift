//
//  Loading Screen.swift
//  test pacman
//
//  Created by Febrian Daniel on 22/03/23.
//

import SwiftUI



struct Loading_Screen: View {
    
    @Binding var currentDisplayScreen: DisplayScreen
    
    var body: some View {
        ZStack {
            Color.black
            VStack(spacing: 8){
                Text("Mac-Man")
                    .font(.custom("Retro Gaming", size: 90))
                    .padding()
                Spacer()
                    .frame(height: 250)
                Button{
                    self.currentDisplayScreen = .maze
                }label: {
                    Text("ENTER")
                        .frame(width: 170, height: 50)
                        .font(.custom("Retro Gaming", size: 25))
                        .background(.white)
                        .foregroundColor(.black)
                        .cornerRadius(8)
                }
                .padding()
                .buttonStyle(.plain)
                
                Spacer()
                    .frame(height: 50)
            }
        }
    }
}

struct Loading_Screen_Previews: PreviewProvider {
    static var previews: some View {
        Loading_Screen(currentDisplayScreen: .constant(.loadingScreen))
    }
}
