//
//  test_pacmanApp.swift
//  test pacman
//
//  Created by Febrian Daniel on 20/03/23.
//

import SwiftUI

@main
struct test_pacmanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
